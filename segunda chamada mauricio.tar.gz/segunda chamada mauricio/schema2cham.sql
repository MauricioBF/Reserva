﻿CREATE TABLE filme (
	id serial,
	nome varchar(100) NOT NULL,
	duracao int NOT NULL, --minutos
	lancamento date NOT NULL,
	CONSTRAINT "filmePK" PRIMARY KEY (id));

CREATE TABLE genero (
	id serial,
	nome varchar(100) NOT NULL,
	CONSTRAINT "generoPK" PRIMARY KEY (id));

CREATE TABLE "filmeGenero" (
	idFilme int,
	idGenero int,
	CONSTRAINT "filmeGeneroPK" PRIMARY KEY (idFilme,idGenero),
	CONSTRAINT "filmeGeneroGeneroFK" FOREIGN KEY (idGenero) REFERENCES genero (id),
	CONSTRAINT "filmeGeneroFilmeFK" FOREIGN KEY (idFilme) REFERENCES filme(id));

INSERT INTO genero (nome) VALUES 
	('Terror'),('Suspense'),
	('Ação'),('Aventura');
