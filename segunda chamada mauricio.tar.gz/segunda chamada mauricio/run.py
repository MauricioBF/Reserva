from flask import Flask, render_template
from .app import db
from .app.controllers.filme import filme 
from .app.models.genero import genero 
import os

app = Flask(__name__, template_folder='app/templates')
app.register_blueprint(filme)

uri = 'postgresql://postgres:postgres@localhost:5432/imdbds2'
app.config['SQLALCHEMY_DATABASE_URI'] = uri 

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
app.config['SECRET_KEY'] = 'minhakey'
app.debug = True 
db.init_app(app)

@app.route('/')
def main():
    app.env = 'development'
    app.run(debug=True, port=8000)
def index():
    return render_template('lista.html')

@app.route('/create')
def create():
    db.create_all()
    return 'Tabelas criadas!'

@app.route('/drop')
def drop():
    db.drop_all()
    return 'Tabelas deletadas!'

@app.route('/popula_generos')
def popula_generoes():
    novogenero = Genero(nome='Terror')
    genero.adicionar(novogenero)
    novogenero = Genero(nome='Suspense')
    genero.adicionar(novogenero)
    novogenero = Genero(nome='Ação')
    genero.adicionar(novogenero)
    novogenero = Genero(nome='Aventura')
    genero.adicionar(novogenero)
    return 'Gêneros salvos!'

if __name__ == "__main__":
    main()

