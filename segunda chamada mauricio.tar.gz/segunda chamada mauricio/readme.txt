Ativar ambiente virtual (pasta "virtualenv")
Rodar flask por "python run.py"