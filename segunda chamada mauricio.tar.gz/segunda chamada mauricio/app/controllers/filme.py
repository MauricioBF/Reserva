from flask import Flask, Blueprint, request, render_template, redirect
from .. models.genero import Genero
from .. models.filme import Filme
from .. import db
import datetime

filme = Blueprint('filme', __name__, url_prefix='/filme')

@filme.route('/insereGenero')
def insereGenero():
    generos = Genero.query.all()
    return render_template('filme.html', generos=generos)

@filme.route('/inserir', methods=['POST, GET'])
def inserir():
    idsgeneros = request.form.getlist('autores')
    if(idsGeneros == []):
        generos = Genero.query.all()
        return render_template('filme.html', generos=generos, msg='Gênero inválido ou não existe')
    else:
        nome = request.form['nome']
        duracao - request.form['duracao']
        lancamento = request.form['lancamento']
        filme = Filme(nome = nome, duracao=duracao, lancamento=lancamento)
        filme.insert(idsGeneros)
        return redirect("/filme/listar")

@livro.route('/detalhes', methods=['GET'])
def detalhes():
    id = request.values['id']
    filme = LivFilmero.query.get(id)
    return render_template('detalhes.html', filme=filme)

@livro.route('/listar')
def listar():
    filmes = Filme.query.all()
    return render_template('lista.html', filmes=filmes)

