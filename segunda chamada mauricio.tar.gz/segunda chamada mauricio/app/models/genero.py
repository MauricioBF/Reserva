from .. import db 
from sqlalchemy import Column, Integer, String, ForeignKey
from .. models.filme import Filme

filme_genero = db.Table('filmeGenero',
db.Column('idfilme',db. Integer, db. ForeignKey('filme.id'),
primary_key=True),
db.Column('idgenero',db. Integer, db. ForeignKey('genero.id'),
primary_key=True))

class Genero(db.Model):
    __tablename__ = 'genero'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    filmes = db.relationship ('Filme', secondary= filme_genero,
backref= 'genero')

    def __init__(self, nome, duracao, lancamento):
        self.nome = nome

    def adicionar(self):
        db.session.add(self)
        db.session.commit()