from .. import db 
from sqlalchemy import Column, Integer, String, ForeignKey, Date

class Filme(db.Model):
    __tablename__ = 'filme'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    duracao = db.Column(db.Integer(50), nullable=False)
    lancamento = db.Column(db.Date, nullable=False)

    def __init__(self, nome, duracao, lancamento):
        self.nome = nome
        self.duracao = duracao
        self.lancamento = lancamento

    def adicionar(self):
        db.session.add(e)
        db.session.commit()

    def excluir(self):
        db.session.delete(self)
        db.session.commit()

    def listar():
        return filme.query.all()

    def buscar(id):
        return filme.query.filter_by(id=id).first()